const CONFIG = {
  HoverWidth: 10,
  Lang: "en",
};

import { css, run } from "uebersicht";

export const refreshFrequency = false;

var style = {
  ip: css`
    user-select: none;
    position: fixed;
    top: 20px;
    right: 10px;
    color: #fff;
    cursor: copy;
    border: 1px solid #fff;
    background: rgba(0, 0, 0, 0);
    font-size: 24px;
    font-weight: 100;
    padding: 4px 6px 4px 6px;
    min-height: 25px;
    min-width: 80px;
    float: right;
    &:after {
      content: "Public IP";
      position: absolute;
      right: 0;
      top: -14px;
      font-size: 10px;
      font-weight: 500;
      display: inline;
    }
  `,
  downloadMP3: css`
    user-select: none;
    position: fixed;
    top: 80px;
    right: 10px;
    color: #fff;
    border: 1px solid #fff;
    cursor: pointer;
    background: rgba(0, 0, 0, 0);
    font-size: 24px;
    font-weight: 100;
    padding: 4px 8px 4px 8px;
    float: right;
    border-style: solid solid solid dashed;
    text-align: center;
    &:after {
      content: "YouTube-dl";
      position: absolute;
      right: 0;
      top: -14px;
      font-size: 10px;
      font-weight: 500;
      display: inline;
    }
  `,
  downloadMP4: css`
    user-select: none;
    position: fixed;
    top: 80px;
    right: 74px;
    color: #fff;
    border: 1px solid #fff;
    border-style: solid none solid solid;
    cursor: pointer;
    background: rgba(0, 0, 0, 0);
    font-size: 24px;
    font-weight: 100;
    padding: 4px 8px 4px 8px;
    float: right;
    text-align: center;
  `,
  notificationBox: css`
    position: fixed;
    background-color: rgb(32, 33, 36);
    box-shadow: 0px 0px 35px 0px rgba(0, 0, 0, 1);
    color: white;
    bottom: -10px;
    left: 10px;
    display: inline;
    opacity: 0;
    cursor: default;
    padding: 12px;
    border-radius: 10px;
  `,
  widgetContent: css`
    user-select: none;
    right: 0;
    opacity: 0;
    visibility: hidden;
  `,
  rightHover: css`
    user-select: none;
    position: fixed;
    height: 100%;
    width: ${CONFIG.HoverWidth}px;
    right: 0;
    top: 0;
    opacity: 0;
    visibility: visible;
  `,
  rightGradient: css`
    user-select: none;
    width: 150px;
    height: 100%;
    position: fixed;
    right: 0;
    top: 0;
    opacity: 0;
    visibility: hidden;
    backdrop-filter: blur(2px);
    -webkit-backdrop-filter: blur(2px);
    background: linear-gradient(
      to left,
      rgba(0, 0, 0, 0.45),
      75%,
      rgba(0, 0, 0, 0)
    );
  `,
};

export const render = ({ output, error }) => {
  return (
    <div id="content">
      <div className={style.rightGradient} id="rightGradient">
        <div className={style.rightHover} id="rightHover"></div>
      </div>
      <div className={style.widgetContent} id="widgetContent">
        <div className={style.ip} id="ip">
          Loading...
        </div>
        <div className={style.downloadMP3} id="yt-download-button">
          MP3
        </div>
        <div className={style.downloadMP4} id="yt-download-button-MP4">
          MP4
        </div>
      </div>
      <div className={style.notificationBox} id="Notification"></div>
    </div>
  );
};

var start = () => {
  //initialize
  //ip clipboard
  document.getElementById("ip").addEventListener("click", () => {
    if (
      document.getElementById("ip").innerText != "Offline..." &&
      document.getElementById("ip").innerText != "Loading..."
    ) {
      navigator.clipboard.writeText(document.getElementById("ip").innerText);
      util.alert("IP Address Copied to Clipboard.");
    } else {
      util.alert("No Internet Connection.");
    }
  });

  //IP update
  window.addEventListener("online", () => {
    util.request("https://api.ipify.org/", (res, err) => {
      if (err) {
        document.getElementById("ip").innerText = "Offline...";
        util.alert(`[IP fetch]: Error; Reason: ${err}.`);
      } else {
        document.getElementById("ip").innerText = res;
        util.alert(`[IP fetch]: Internet Connected.`);
      }
    });
  });
  window.addEventListener("offline", () => {
    document.getElementById("ip").innerText = "Offline...";
    util.alert(`[IP fetch]: No Internet Connection.`);
  });
  if (navigator.onLine) {
    util.request("https://api.ipify.org/", (res, err) => {
      if (err) {
        document.getElementById("ip").innerText = "Offline...";
        util.alert(`[IP fetch]: Error; Reason: ${err}.`);
      } else {
        document.getElementById("ip").innerText = res;
        util.alert(`[IP fetch]: Internet Connected.`);
      }
    });
  } else {
    document.getElementById("ip").innerText = "Offline...";
    util.alert(`[IP fetch]: No Internet Connection.`);
  }

  let mouseOver = {
    widgetContent: false,
    rightHover: false,
  };
  document.getElementById("widgetContent").onmouseover = () => {
    mouseOver.widgetContent = true;
  };
  document.getElementById("widgetContent").onmouseleave = () => {
    setTimeout(() => {
      mouseOver.widgetContent = false;
      if (mouseOver.rightHover) return;
      document.getElementById(
        "rightHover"
      ).style.width = `${CONFIG.HoverWidth}px`;
      util.fade.out("widgetContent");
      util.fade.out("rightGradient");
    }, 10);
  };
  document.getElementById("rightHover").onmouseover = () => {
    mouseOver.rightHover = true;
    setTimeout(() => {
      if (mouseOver.widgetContent) return;
      document.getElementById("rightGradient").style.width =
        document.getElementById("ip").style.width;
      document.getElementById("rightHover").style.width = "100px";
      util.fade.in("widgetContent");
      util.fade.in("rightGradient");
    }, 5);
  };
  document.getElementById("rightHover").onmouseleave = () => {
    mouseOver.rightHover = false;
    setTimeout(() => {
      if (mouseOver.widgetContent) return;
      document.getElementById(
        "rightHover"
      ).style.width = `${CONFIG.HoverWidth}px`;
      util.fade.out("widgetContent");
      util.fade.out("rightGradient");
    }, 10);
  };

  var ytMenuShown = false;

  //YouTube Download Button MP3
  document.getElementById("yt-download-button").onclick = (e) => {
    e.preventDefault();
    navigator.clipboard.readText().then(
      (url) => {
        if (
          document.getElementById("ip").innerText == "Offline..." ||
          document.getElementById("ip").innerText == "Loading..."
        ) {
          return util.alert("No Internet Connection.");
        }
        if (!url.includes("/") || !url.includes("youtu"))
          return util.alert("This link is not a valid YouTube URL.");
        util.alert(`Now Downloading From ${url}.`);
        run(
          `cd "$HOME/Downloads";/usr/local/bin/youtube-dl --no-playlist -x --audio-format mp3 --add-metadata --no-part --xattrs --embed-thumbnail '${url}'`
        ).then((output) => {
          console.log(output);
          if (output.includes("command not found")) {
            return util.alert("Youtube-dl is not Installed.");
          }
          if (output.includes("is not a valid URL.")) {
            return util.alert("This is Not a Valid YouTube URL.");
          }
          if (
            output.includes(
              "ERROR: ffprobe/avprobe and ffmpeg/avconv not found. Please install one."
            )
          ) {
            return util.alert(
              "FFMPEG Not Found or Load BASH Env is Not Enabled."
            );
          }
          util.alert("MP3 Downloaded Successfully");
        });
      },
      () => {}
    );

    //YouTube Download Button MP4
    document.getElementById("yt-download-button-MP4").onclick = (e) => {
      e.preventDefault();
      navigator.clipboard.readText().then(
        (url) => {
          if (
            document.getElementById("ip").innerText == "Offline..." ||
            document.getElementById("ip").innerText == "Loading..."
          ) {
            return util.alert("No Internet Connection.");
          }
          if (!url.includes("/") || !url.includes("youtu"))
            return util.alert("This link is not a valid YouTube URL.");
          util.alert(`Now Downloading From ${url}.`);
          run(
            `cd "$HOME/Downloads";/usr/local/bin/youtube-dl --no-playlist --no-part --embed-subs -f mp4 --sub-lang ${CONFIG.Lang} '${url}'`
          ).then((output) => {
            console.log(output);
            if (output.includes("command not found")) {
              return util.alert("Youtube-dl Not Found.");
            }
            if (output.includes("is not a valid URL.")) {
              return util.alert("This Link is Not a Valid YouTube URL.");
            }
            if (
              output.includes(
                "ERROR: ffprobe/avprobe and ffmpeg/avconv not found. Please install one."
              )
            ) {
              return util.alert(
                "FFMPEG Not Found or Load BASH Env is Not Enabled."
              );
            }
            util.alert("MP4 Downloaded Successfully");
          });
        },
        () => {}
      );
    };
  };

  //YouTube Download Button MP4
  document.getElementById("yt-download-button-MP4").onclick = (e) => {
    e.preventDefault();
    navigator.clipboard.readText().then(
      (url) => {
        if (
          document.getElementById("ip").innerText == "Offline..." ||
          document.getElementById("ip").innerText == "Loading..."
        ) {
          return util.alert("No Internet Connection.");
        }
        if (!url.includes("/") || !url.includes("youtu"))
          return util.alert("This link is not a valid YouTube URL.");
        util.alert(`Now Downloading From ${url}.`);
        run(
          `cd "$HOME/Downloads";/usr/local/bin/youtube-dl --no-playlist --no-part --embed-subs -f mp4 --sub-lang ${CONFIG.Lang} '${url}'`
        ).then((output) => {
          console.log(output);
          if (output.includes("command not found")) {
            return util.alert("Youtube-dl Not Found.");
          }
          if (output.includes("is not a valid URL.")) {
            return util.alert("This Link is Not a Valid YouTube URL.");
          }
          if (
            output.includes(
              "ERROR: ffprobe/avprobe and ffmpeg/avconv not found. Please install one."
            )
          ) {
            return util.alert(
              "FFMPEG Not Found or Load BASH Env is Not Enabled."
            );
          }
          util.alert("MP4 Downloaded Successfully");
        });
      },
      () => {}
    );
  };
};

var startTimer = setInterval(() => {
  start();
  if (document.getElementById("ip")) clearInterval(startTimer);
}, 1000);

/**
 * @description A utility kit commonly used by Hypersun_pro
 */
var util = {
  /**
   * @callback resCB
   * @param {string} res - Response from the GET request, empty string of error found
   * @param {string} err - Error response from the GET request, Null if no error found
   */
  /**
   * @description - Send http GET request
   * @param {string} url - URL to send request to
   * @param {resCB} callback - A callback function
   */
  request: function (url, callback) {
    let UrlFetch = new XMLHttpRequest();
    UrlFetch.open("GET", url);
    UrlFetch.send();
    UrlFetch.ontimeout = () => {
      callback("", "Timed out");
    };
    UrlFetch.addEventListener("load", () => {
      if (UrlFetch.status.toString().startsWith("2")) {
        callback(UrlFetch.response, null);
      } else {
        callback("", UrlFetch.status);
      }
    });
    UrlFetch.timeout = 10000;
  },
  fade: {
    /**
     * @description - Fade in an HTML element
     * @param {string} id - id of the element to be faded in
     * @function
     */
    in: function (id) {
      if (document.getElementById(id) == "visible") return;
      document.getElementById(id).style.visibility = "visible";
      let op = 0;
      let timer = setInterval(function () {
        if (op >= 1) {
          clearInterval(timer);
        }
        document.getElementById(id).style.opacity = op;
        op = Math.round((op + 0.1) * 10) / 10;
      }, 25);
    },
    /**
     * @description - Fade out an HTML element
     * @param {string} id - id of the element to be faded out
     * @param {boolean} hide - Make the DOM hidden after the process is done, true by default
     * @function
     */
    out: function (id, hide) {
      if (document.getElementById(id) == "hidden") return;
      let fop = 1;
      let timer = setInterval(function () {
        document.getElementById(id).style.opacity = fop;
        fop = Math.round((fop - 0.1) * 10) / 10;
        if (fop < 0) {
          clearInterval(timer);
          if (hide === false) return;
          document.getElementById(id).style.visibility = "hidden";
        }
      }, 25);
    },
  },
  /**
   * @description Pop an alert box to the user
   * @param {String} message - Message to alert
   */
  alert: function (message) {
    let shown = false;
    document.getElementById("Notification").innerHTML = message;
    function enter() {
      shown = true;
      let op = 0;
      let timer = setInterval(function () {
        if (op >= 1) {
          clearInterval(timer);
        }
        document.getElementById("Notification").style.opacity = op;
        document.getElementById("Notification").style.bottom =
          op * 30 - 20 + "px";
        op = Math.round((op + 0.1) * 10) / 10;
      }, 10);
    }
    enter();

    //Click to hide notification
    document.getElementById("Notification").addEventListener("click", () => {
      fade();
    });

    setTimeout(() => {
      fade();
    }, 5000);

    function fade() {
      let fop = 1;
      let timer = setInterval(function () {
        document.getElementById("Notification").style.opacity = fop;
        document.getElementById("Notification").style.bottom =
          fop * 30 - 20 + "px";
        fop = Math.round((fop - 0.1) * 10) / 10;
        if (fop < 0) {
          clearInterval(timer);
        }
      }, 10);
    }
    enter();
  },
};
